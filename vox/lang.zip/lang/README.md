# accounting for change

1. account for increased vocabulary
2. account for different grammar
